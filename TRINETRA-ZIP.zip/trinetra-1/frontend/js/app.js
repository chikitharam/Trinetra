/* TRINETRA Core SPA Controller & State Engine */

document.addEventListener('DOMContentLoaded', () => {
    TrinetraApp.init();
});

class TrinetraApp {
    static state = {
        activeCommunity: 'STUDENT',
        activeView: 'dashboard',
        currentUser: null,
        threatsCache: [],
        dashCache: null,
        alertsCache: []
    };

    static init() {
        console.log('[TRINETRA INIT] Initializing application...');
        this.bindEvents();
        this.checkAuthState();
    }

    static checkAuthState() {
        const stored = localStorage.getItem('trinetra_user');
        if (stored) {
            try {
                this.state.currentUser = JSON.parse(stored);
                if (this.state.currentUser && this.state.currentUser.community) {
                    this.state.activeCommunity = this.state.currentUser.community.toUpperCase();
                }
                console.log('[TRINETRA AUTH] User authenticated:', this.state.currentUser.email, 'Community:', this.state.activeCommunity);
                this.onUserAuthenticated();
                return;
            } catch (e) {
                console.error('[TRINETRA AUTH] Error parsing stored user session:', e);
                localStorage.removeItem('trinetra_user');
            }
        }
        
        console.log('[TRINETRA AUTH] Unauthenticated state. Rendering Login Screen.');
        this.onUserUnauthenticated();
    }

    static onUserAuthenticated() {
        // Show Header & Footer
        document.getElementById('main-header')?.classList.remove('hidden');
        document.getElementById('main-footer')?.classList.remove('hidden');

        // Hide Standalone Auth View
        document.getElementById('view-auth')?.classList.add('hidden');

        // Sync header user name & community selector
        const user = this.state.currentUser;
        const nameEl = document.getElementById('header-user-name');
        if (nameEl) nameEl.textContent = user ? (user.name || user.email) : 'Cyber Citizen';

        const commSel = document.getElementById('community-selector');
        if (commSel) commSel.value = this.state.activeCommunity;

        // Render Active View (Default: Dashboard)
        this.renderView('dashboard');
        this.refreshAlerts();
    }

    static onUserUnauthenticated() {
        // Hide Header & Footer
        document.getElementById('main-header')?.classList.add('hidden');
        document.getElementById('main-footer')?.classList.add('hidden');

        // Hide all application views
        document.querySelectorAll('.view-section').forEach(sec => sec.classList.add('hidden'));

        // Render ONLY Standalone Auth Screen
        const authView = document.getElementById('view-auth');
        if (authView) authView.classList.remove('hidden');
    }

    static handleLogout() {
        console.log('[TRINETRA AUTH] User logged out.');
        this.state.currentUser = null;
        localStorage.removeItem('trinetra_user');
        this.onUserUnauthenticated();
    }

    static bindEvents() {
        // Navigation Bar Buttons
        document.querySelectorAll('.nav-btn, .mobile-nav-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const view = btn.getAttribute('data-view');
                if (view && this.state.currentUser) {
                    this.renderView(view);
                    document.getElementById('mobile-menu')?.classList.add('hidden');
                }
            });
        });

        // Brand click -> Go to Dashboard
        document.getElementById('nav-brand')?.addEventListener('click', () => {
            if (this.state.currentUser) this.renderView('dashboard');
        });

        // Logout Button
        document.getElementById('logout-btn')?.addEventListener('click', () => {
            this.handleLogout();
        });

        // Community Selector Switcher (Live persona switch)
        const commSel = document.getElementById('community-selector');
        if (commSel) {
            commSel.addEventListener('change', (e) => {
                const newComm = e.target.value.toUpperCase();
                console.log('[TRINETRA USER] Community target switched to:', newComm);
                this.state.activeCommunity = newComm;
                if (this.state.currentUser) {
                    this.state.currentUser.community = newComm;
                    localStorage.setItem('trinetra_user', JSON.stringify(this.state.currentUser));
                }
                this.updateUserHeaderUI();
                this.loadDashboardData();
                this.refreshAlerts();
            });
        }

        // Mobile Menu Toggle
        document.getElementById('mobile-menu-btn')?.addEventListener('click', () => {
            document.getElementById('mobile-menu')?.classList.toggle('hidden');
        });

        // Refresh Feed Button
        document.getElementById('quick-verify-btn')?.addEventListener('click', () => {
            this.loadDashboardData();
        });

        // Search & Filters Input Listeners
        const searchInput = document.getElementById('search-input');
        const filterComm = document.getElementById('filter-community');
        const filterSev = document.getElementById('filter-severity');

        if (searchInput) searchInput.addEventListener('input', () => this.handleSearch());
        if (filterComm) filterComm.addEventListener('change', () => this.handleSearch());
        if (filterSev) filterSev.addEventListener('change', () => this.handleSearch());
        
        document.getElementById('reset-filters-btn')?.addEventListener('click', () => {
            if (searchInput) searchInput.value = '';
            if (filterComm) filterComm.value = 'ALL';
            if (filterSev) filterSev.value = 'ALL';
            this.handleSearch();
        });

        // AI Chat Form Submit
        document.getElementById('chat-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleChatSubmit();
        });

        // Chat Preset Prompts
        document.querySelectorAll('.chat-preset-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const text = btn.textContent.replace('💬', '').replace(/"/g, '').trim();
                const chatInput = document.getElementById('chat-input');
                if (chatInput) {
                    chatInput.value = text;
                    this.handleChatSubmit();
                }
            });
        });

        // Incident Report Form
        document.getElementById('report-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleReportSubmit();
        });

        // Share Experience Modal Buttons
        document.getElementById('open-share-exp-btn')?.addEventListener('click', () => {
            document.getElementById('experience-modal')?.classList.remove('hidden');
        });
        document.getElementById('close-exp-modal-btn')?.addEventListener('click', () => {
            document.getElementById('experience-modal')?.classList.add('hidden');
        });
        document.getElementById('exp-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleExperienceSubmit();
        });

        // Threat Details Modal Close Button
        document.getElementById('close-modal-btn')?.addEventListener('click', () => {
            document.getElementById('threat-modal')?.classList.add('hidden');
        });

        // Standalone Auth Form Submit
        document.getElementById('standalone-auth-form')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleStandaloneAuthSubmit();
        });

        // Auth Form Mode Toggle (Sign In vs Sign Up)
        document.getElementById('auth-main-toggle-btn')?.addEventListener('click', () => {
            const submitBtn = document.getElementById('auth-main-submit-btn');
            const isSignIn = submitBtn.textContent.includes('SIGN IN');
            this.setAuthFormMode(isSignIn ? 'signup' : 'login');
        });

        // Health / Admin SOC Action Buttons
        document.getElementById('trigger-reseed-btn')?.addEventListener('click', async () => {
            try {
                const res = await TrinetraAPI.triggerSeed();
                alert('Database re-seeded successfully with 60 community threats!');
                this.loadHealthData();
            } catch (err) {
                alert('Seeding error: ' + err.message);
            }
        });

        document.getElementById('trigger-osint-btn')?.addEventListener('click', async () => {
            try {
                const btn = document.getElementById('trigger-osint-btn');
                btn.disabled = true;
                btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-1"></i> Running...';
                const res = await TrinetraAPI.triggerOSINTCollector();
                alert(`OSINT Collector finished! Fetched ${res.collector_results.fetched_count} feeds, inserted ${res.collector_results.new_inserted} new threats.`);
                btn.disabled = false;
                btn.innerHTML = '<i class="fa-solid fa-rss mr-1"></i> Trigger OSINT Collector';
                this.loadHealthData();
            } catch (err) {
                alert('Collector error: ' + err.message);
            }
        });
    }

    static setAuthFormMode(mode) {
        const submitBtn = document.getElementById('auth-main-submit-btn');
        const fieldName = document.getElementById('auth-field-name');
        const fieldComm = document.getElementById('auth-field-community');
        const togglePrompt = document.getElementById('auth-main-toggle-prompt');
        const toggleBtn = document.getElementById('auth-main-toggle-btn');
        const errBox = document.getElementById('auth-error-alert');

        if (errBox) errBox.classList.add('hidden');

        if (mode === 'signup') {
            submitBtn.innerHTML = '<i class="fa-solid fa-user-plus mr-2"></i> CREATE ACCOUNT';
            fieldName?.classList.remove('hidden');
            fieldComm?.classList.remove('hidden');
            if (togglePrompt) togglePrompt.textContent = 'Already have an account?';
            if (toggleBtn) toggleBtn.textContent = 'Sign In Now';
        } else {
            submitBtn.innerHTML = '<i class="fa-solid fa-right-to-bracket mr-2"></i> SIGN IN';
            fieldName?.classList.add('hidden');
            fieldComm?.classList.add('hidden');
            if (togglePrompt) togglePrompt.textContent = "Don't have an account?";
            if (toggleBtn) toggleBtn.textContent = 'Sign Up Now';
        }
    }

    static async handleStandaloneAuthSubmit() {
        const submitBtn = document.getElementById('auth-main-submit-btn');
        const isSignUp = submitBtn.textContent.includes('CREATE ACCOUNT');
        const email = document.getElementById('auth-input-email').value.trim();
        const password = document.getElementById('auth-input-password').value;
        const errBox = document.getElementById('auth-error-alert');
        const errText = document.getElementById('auth-error-text');

        if (errBox) errBox.classList.add('hidden');

        try {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin mr-2"></i> Authenticating...';

            let user = null;
            if (isSignUp) {
                const name = document.getElementById('auth-input-name').value.trim() || 'Cyber Citizen';
                const comm = document.getElementById('auth-input-community').value;
                const res = await TrinetraAPI.registerUser({
                    name,
                    email,
                    password,
                    community: comm,
                    region: 'National',
                    language: 'English'
                });
                user = res.user;
            } else {
                const res = await TrinetraAPI.loginUser(email, password);
                user = res.user;
            }

            if (user) {
                this.state.currentUser = user;
                this.state.activeCommunity = user.community ? user.community.toUpperCase() : 'STUDENT';
                localStorage.setItem('trinetra_user', JSON.stringify(user));
                
                console.log('[TRINETRA AUTH] Login successful. Profile loaded from Firestore:', user);
                this.onUserAuthenticated();
            }
        } catch (err) {
            console.error('[TRINETRA AUTH Error]', err);
            if (errBox && errText) {
                errText.textContent = err.message || 'Authentication failed. Please try again.';
                errBox.classList.remove('hidden');
            } else {
                alert('Authentication failed: ' + err.message);
            }
        } finally {
            submitBtn.disabled = false;
            this.setAuthFormMode(isSignUp ? 'signup' : 'login');
        }
    }

    static renderView(viewName) {
        if (!this.state.currentUser) {
            this.onUserUnauthenticated();
            return;
        }

        this.state.activeView = viewName;
        console.log('[TRINETRA ROUTING] Rendering view:', viewName);

        // Hide all views
        document.querySelectorAll('.view-section').forEach(sec => sec.classList.add('hidden'));

        // Highlight active nav button
        document.querySelectorAll('.nav-btn').forEach(btn => {
            if (btn.getAttribute('data-view') === viewName) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });

        // Show target view
        const targetView = document.getElementById(`view-${viewName}`);
        if (targetView) {
            targetView.classList.remove('hidden');
        }

        // View specific data loaders
        if (viewName === 'dashboard') {
            this.loadDashboardData();
        } else if (viewName === 'threats') {
            this.loadThreatsMatrixData();
        } else if (viewName === 'reviews') {
            this.loadReviewsData();
        } else if (viewName === 'health') {
            this.loadHealthData();
        } else if (viewName === 'assistant') {
            const chatComm = document.getElementById('chat-active-comm');
            if (chatComm) chatComm.textContent = this.formatCommunityName(this.state.activeCommunity);
        }
    }

    static updateUserHeaderUI() {
        const user = this.state.currentUser;
        const nameEl = document.getElementById('dash-user-name');
        const badgeEl = document.getElementById('dash-comm-badge');
        const headerNameEl = document.getElementById('header-user-name');

        if (nameEl) nameEl.textContent = user ? (user.name || 'Cyber Citizen') : 'Cyber Citizen';
        if (badgeEl) badgeEl.textContent = this.formatCommunityName(this.state.activeCommunity);
        if (headerNameEl) headerNameEl.textContent = user ? (user.name || user.email) : 'Cyber Citizen';
    }

    static formatCommunityName(comm) {
        switch ((comm || '').toUpperCase()) {
            case 'STUDENT': return 'Student';
            case 'SENIOR_CITIZEN': return 'Senior Citizen';
            case 'SMALL_BUSINESS': return 'Small Business';
            case 'REGIONAL_COMMUNITY': return 'Regional Community';
            default: return comm || 'Student';
        }
    }

    static getSeverityBadgeHtml(severity) {
        const s = (severity || 'HIGH').toUpperCase();
        switch (s) {
            case 'CRITICAL': return `<span class="badge-critical"><i class="fa-solid fa-triangle-exclamation mr-1"></i> CRITICAL</span>`;
            case 'HIGH': return `<span class="badge-high"><i class="fa-solid fa-fire mr-1"></i> HIGH</span>`;
            case 'MEDIUM': return `<span class="badge-medium"><i class="fa-solid fa-circle-info mr-1"></i> MEDIUM</span>`;
            default: return `<span class="badge-low"><i class="fa-solid fa-shield mr-1"></i> LOW</span>`;
        }
    }

    // --- DASHBOARD DATA LOADER ---
    static async loadDashboardData() {
        this.updateUserHeaderUI();

        const highGrid = document.getElementById('high-priority-grid');
        const allGrid = document.getElementById('all-threats-grid');

        if (highGrid) {
            highGrid.innerHTML = `
                <div class="col-span-full py-12 text-center text-slate-400 bg-slate-900/60 border border-slate-800 rounded-lg">
                    <i class="fa-solid fa-spinner fa-spin text-2xl text-cyan-400 mb-3"></i>
                    <p class="text-sm font-semibold text-slate-200">Retrieving Firestore threat feed for ${this.formatCommunityName(this.state.activeCommunity)}...</p>
                    <p class="text-xs text-slate-400 mt-1">Applying community classification & severity prioritization score</p>
                </div>
            `;
        }

        try {
            console.log('[TRINETRA FIRESTORE] Querying dashboard CTI feed for community:', this.state.activeCommunity);
            const userId = this.state.currentUser ? this.state.currentUser.id : null;
            const data = await TrinetraAPI.getDashboard(this.state.activeCommunity, userId);
            this.state.dashCache = data;

            console.log('[TRINETRA DASHBOARD] Loaded', data.total_relevant_threats, 'relevant threats from Firestore.');

            // Update Statistics Counters
            const totalEl = document.getElementById('stat-total-count');
            const highEl = document.getElementById('stat-high-count');
            const medEl = document.getElementById('stat-med-count');

            if (totalEl) totalEl.textContent = data.total_relevant_threats || 0;
            if (highEl) highEl.textContent = data.high_priority_count || 0;
            const medLow = (data.severity_counts?.MEDIUM || 0) + (data.severity_counts?.LOW || 0);
            if (medEl) medEl.textContent = medLow;

            // Update Safety Tip
            if (data.safety_tip) {
                const tipTitle = document.getElementById('safety-tip-title');
                const tipBody = document.getElementById('safety-tip-body');
                if (tipTitle) tipTitle.textContent = data.safety_tip.title;
                if (tipBody) tipBody.textContent = data.safety_tip.tip;
            }

            // Render High Priority Grid
            if (highGrid) {
                if (!data.high_priority || data.high_priority.length === 0) {
                    highGrid.innerHTML = `
                        <div class="col-span-full p-8 text-center text-slate-400 bg-slate-900 border border-slate-800 rounded-lg">
                            <i class="fa-solid fa-shield-check text-2xl text-emerald-400 mb-2"></i>
                            <p>No high-priority threats currently targeting this community.</p>
                        </div>
                    `;
                } else {
                    highGrid.innerHTML = data.high_priority.map(t => this.renderThreatCard(t)).join('');
                }
            }

            // Render Complete Feed Grid
            if (allGrid) {
                if (!data.threats || data.threats.length === 0) {
                    allGrid.innerHTML = `
                        <div class="col-span-full p-8 text-center text-slate-400 bg-slate-900 border border-slate-800 rounded-lg">
                            <i class="fa-solid fa-folder-open text-2xl text-slate-500 mb-2"></i>
                            <p>No threats found for your current community feed.</p>
                        </div>
                    `;
                } else {
                    allGrid.innerHTML = data.threats.map(t => this.renderThreatCard(t)).join('');
                }
            }

        } catch (err) {
            console.error('[TRINETRA FIRESTORE Error]', err);
            const errHtml = `
                <div class="col-span-full p-8 text-center bg-slate-900 border border-rose-900/60 rounded-lg space-y-3">
                    <i class="fa-solid fa-triangle-exclamation text-3xl text-rose-400"></i>
                    <h3 class="text-base font-bold text-white">Unable to load threat intelligence from Firestore</h3>
                    <p class="text-xs text-slate-400 max-w-md mx-auto">${err.message || 'Connection error to backend database'}</p>
                    <button class="bg-rose-900 hover:bg-rose-800 text-white font-bold text-xs px-4 py-2 rounded-lg transition" onclick="TrinetraApp.loadDashboardData()">
                        <i class="fa-solid fa-sync mr-1.5"></i> Retry Connection
                    </button>
                </div>
            `;
            if (highGrid) highGrid.innerHTML = errHtml;
            if (allGrid) allGrid.innerHTML = errHtml;
        }
    }

    static renderThreatCard(threat) {
        const platforms = Array.isArray(threat.platform) ? threat.platform.join(', ') : (threat.platform || 'Web');

        return `
            <div class="soc-card soc-card-interactive p-5 flex flex-col justify-between space-y-4">
                <div>
                    <div class="flex items-center justify-between mb-2">
                        ${this.getSeverityBadgeHtml(threat.severity)}
                        <span class="text-[11px] font-mono text-slate-400"><i class="fa-solid fa-laptop mr-1"></i> ${platforms}</span>
                    </div>

                    <h3 class="text-base font-bold text-white mb-1.5 hover:text-cyan-400 transition cursor-pointer" onclick="TrinetraApp.openThreatModal('${threat.id}')">
                        ${threat.title}
                    </h3>

                    <p class="text-xs text-slate-300 leading-relaxed line-clamp-3">
                        ${threat.description}
                    </p>
                </div>

                <div class="pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                    <span class="text-slate-400 font-mono text-[11px]"><i class="fa-solid fa-users text-cyan-400 mr-1"></i> ${this.formatCommunityName(threat.community)}</span>
                    <button class="bg-slate-800 hover:bg-cyan-600 hover:text-slate-950 text-cyan-400 font-semibold px-3 py-1.5 rounded transition text-xs flex items-center" onclick="TrinetraApp.openThreatModal('${threat.id}')">
                        READ MORE <i class="fa-solid fa-arrow-right ml-1.5"></i>
                    </button>
                </div>
            </div>
        `;
    }

    // --- THREAT DETAILS MODAL ---
    static async openThreatModal(threatId) {
        const modal = document.getElementById('threat-modal');
        if (!modal) return;

        try {
            let threat = null;
            if (this.state.dashCache && this.state.dashCache.threats) {
                threat = this.state.dashCache.threats.find(t => t.id === threatId);
            }
            if (!threat) {
                threat = await TrinetraAPI.getThreatDetails(threatId);
            }

            if (threat) {
                document.getElementById('modal-sev-badge').className = threat.severity === 'CRITICAL' ? 'badge-critical' : threat.severity === 'HIGH' ? 'badge-high' : threat.severity === 'MEDIUM' ? 'badge-medium' : 'badge-low';
                document.getElementById('modal-sev-badge').textContent = threat.severity;
                document.getElementById('modal-comm-tag').textContent = this.formatCommunityName(threat.community);
                document.getElementById('modal-platform').textContent = Array.isArray(threat.platform) ? threat.platform.join(', ') : threat.platform;
                document.getElementById('modal-title').textContent = threat.title;
                document.getElementById('modal-description').textContent = threat.description;
                document.getElementById('modal-method').textContent = threat.attack_method || 'Social Engineering / Phishing';

                // Indicators
                const indEl = document.getElementById('modal-indicators');
                indEl.innerHTML = (threat.indicators && threat.indicators.length) ? threat.indicators.map(i => `<li>${i}</li>`).join('') : '<li>Check sender authenticity</li>';

                // Identify
                const idEl = document.getElementById('modal-identify');
                idEl.innerHTML = (threat.how_to_identify && threat.how_to_identify.length) ? threat.how_to_identify.map(i => `<li>${i}</li>`).join('') : '<li>Verify official domain</li>';

                // Action
                const actEl = document.getElementById('modal-action');
                actEl.innerHTML = (threat.what_to_do && threat.what_to_do.length) ? threat.what_to_do.map(i => `<li>${i}</li>`).join('') : '<li>Do not send money or OTP</li>';

                // Prevention
                const prevEl = document.getElementById('modal-prevention');
                prevEl.innerHTML = (threat.prevention_tips && threat.prevention_tips.length) ? threat.prevention_tips.map(i => `<li>${i}</li>`).join('') : '<li>Enable Multi-Factor Authentication</li>';

                document.getElementById('modal-source').textContent = threat.source || 'TRINETRA OSINT';
                document.getElementById('modal-date').textContent = threat.published_date ? threat.published_date.split('T')[0] : 'Recent';

                modal.classList.remove('hidden');
            }
        } catch (err) {
            alert('Failed fetching threat document details: ' + err.message);
        }
    }

    // --- SEARCH MATRIX LOADER ---
    static async loadThreatsMatrixData() {
        this.handleSearch();
    }

    static async handleSearch() {
        const query = document.getElementById('search-input')?.value || '';
        const comm = document.getElementById('filter-community')?.value || 'ALL';
        const sev = document.getElementById('filter-severity')?.value || 'ALL';

        const grid = document.getElementById('search-results-grid');
        const countEl = document.getElementById('search-result-count');

        if (grid) grid.innerHTML = `<div class="col-span-full py-8 text-center text-slate-400"><i class="fa-solid fa-spinner fa-spin text-xl text-cyan-400 mb-2"></i><p>Searching Firestore CTI database...</p></div>`;

        try {
            const data = await TrinetraAPI.getThreats({ query, community: comm, severity: sev });
            if (countEl) countEl.textContent = `Showing ${data.total} Threats in Firestore`;

            if (grid) {
                if (data.total === 0) {
                    grid.innerHTML = `<div class="col-span-full p-8 text-center text-slate-400 bg-slate-900 border border-slate-800 rounded-lg"><i class="fa-solid fa-search-minus text-2xl mb-2 text-slate-500"></i><p>No threats match your search criteria.</p></div>`;
                } else {
                    grid.innerHTML = data.threats.map(t => this.renderThreatCard(t)).join('');
                }
            }
        } catch (err) {
            if (grid) grid.innerHTML = `<div class="col-span-full p-6 text-center text-rose-400 bg-slate-900 border border-slate-800 rounded-lg">Search failed: ${err.message}</div>`;
        }
    }

    // --- AI CHAT SUBMIT ---
    static async handleChatSubmit() {
        const input = document.getElementById('chat-input');
        const msg = input.value.trim();
        if (!msg) return;

        input.value = '';
        const messagesBox = document.getElementById('chat-messages');

        // Append User Message
        messagesBox.insertAdjacentHTML('beforeend', `
            <div class="flex items-start justify-end space-x-3">
                <div class="bg-cyan-900/40 border border-cyan-800 text-cyan-100 p-3.5 rounded-2xl rounded-tr-none max-w-xl text-sm leading-relaxed">
                    ${msg}
                </div>
                <div class="w-8 h-8 rounded-full bg-cyan-600 text-slate-950 flex items-center justify-center font-bold text-xs shrink-0">
                    YOU
                </div>
            </div>
        `);

        // Loading indicator
        const loadingId = 'bot-loading-' + Date.now();
        messagesBox.insertAdjacentHTML('beforeend', `
            <div id="${loadingId}" class="flex items-start space-x-3">
                <div class="w-8 h-8 rounded-full bg-indigo-900/80 text-indigo-300 flex items-center justify-center shrink-0 text-sm">
                    <i class="fa-solid fa-robot"></i>
                </div>
                <div class="bg-slate-800/90 border border-slate-700/70 text-slate-400 p-3.5 rounded-2xl rounded-tl-none text-sm">
                    <i class="fa-solid fa-spinner fa-spin mr-2 text-indigo-400"></i> TRINETRA AI is generating community-tailored safety guidance...
                </div>
            </div>
        `);

        messagesBox.scrollTop = messagesBox.scrollHeight;

        try {
            const res = await TrinetraAPI.sendChatMessage(msg, this.state.activeCommunity);
            document.getElementById(loadingId)?.remove();

            const formattedText = res.ai_response.replace(/\n/g, '<br>');

            messagesBox.insertAdjacentHTML('beforeend', `
                <div class="flex items-start space-x-3">
                    <div class="w-8 h-8 rounded-full bg-indigo-900/80 text-indigo-300 flex items-center justify-center shrink-0 text-sm">
                        <i class="fa-solid fa-robot"></i>
                    </div>
                    <div class="bg-slate-800/90 border border-slate-700/70 text-slate-100 p-4 rounded-2xl rounded-tl-none max-w-xl text-sm leading-relaxed space-y-2">
                        ${formattedText}
                    </div>
                </div>
            `);
            messagesBox.scrollTop = messagesBox.scrollHeight;
        } catch (err) {
            document.getElementById(loadingId)?.remove();
            messagesBox.insertAdjacentHTML('beforeend', `
                <div class="text-xs text-rose-400 p-3 bg-rose-950/40 rounded-lg">Error getting AI response: ${err.message}</div>
            `);
        }
    }

    // --- REPORT INCIDENT SUBMIT ---
    static async handleReportSubmit() {
        const comm = document.getElementById('report-community').value;
        const type = document.getElementById('report-threat-type').value;
        const plat = document.getElementById('report-platform').value;
        const contact = document.getElementById('report-url-phone').value;
        const desc = document.getElementById('report-desc').value;

        try {
            const reportData = {
                user_id: this.state.currentUser ? this.state.currentUser.id : 'anonymous',
                community: comm,
                threat_type: type,
                platform: plat,
                url_or_phone: contact,
                description: desc
            };
            await TrinetraAPI.submitReport(reportData);
            document.getElementById('report-form').reset();
            const succ = document.getElementById('report-success-msg');
            if (succ) {
                succ.classList.remove('hidden');
                setTimeout(() => succ.classList.add('hidden'), 5000);
            }
        } catch (err) {
            alert('Failed submitting incident report: ' + err.message);
        }
    }

    // --- REVIEWS & EXPERIENCES LOADER ---
    static async loadReviewsData() {
        const feed = document.getElementById('reviews-feed');
        if (!feed) return;

        feed.innerHTML = `<div class="py-8 text-center text-slate-400"><i class="fa-solid fa-spinner fa-spin text-xl text-cyan-400 mb-2"></i><p>Loading community experiences from Firestore...</p></div>`;

        try {
            const data = await TrinetraAPI.getReviews(null, this.state.activeCommunity);
            if (!data.reviews || data.reviews.length === 0) {
                feed.innerHTML = `
                    <div class="soc-card p-6 text-center text-slate-400 bg-slate-900 border border-slate-800">
                        No community experiences shared yet for ${this.formatCommunityName(this.state.activeCommunity)}. Be the first to share!
                    </div>
                `;
            } else {
                feed.innerHTML = data.reviews.map(r => `
                    <div class="soc-card p-5 bg-slate-900 border border-slate-800 space-y-3">
                        <div class="flex items-center justify-between">
                            <div class="flex items-center space-x-2">
                                <div class="w-8 h-8 rounded-full bg-purple-950 text-purple-300 font-bold flex items-center justify-center text-xs">
                                    <i class="fa-solid fa-user-shield"></i>
                                </div>
                                <div>
                                    <span class="text-sm font-bold text-white block">${r.user_alias || 'Community Member'}</span>
                                    <span class="text-[11px] text-slate-400 font-mono">${this.formatCommunityName(r.community)} • ${r.platform || 'WhatsApp'}</span>
                                </div>
                            </div>
                            <span class="text-xs font-semibold text-purple-400 bg-purple-950 px-2.5 py-1 rounded border border-purple-800/60">${r.threat_title}</span>
                        </div>
                        <p class="text-xs text-slate-300 leading-relaxed italic">
                            "${r.experience_text}"
                        </p>
                        <div class="text-[11px] text-emerald-400 font-medium flex items-center">
                            <i class="fa-solid fa-check-circle mr-1"></i> Action Taken: ${r.action_taken || 'Reported & Blocked'}
                        </div>
                    </div>
                `).join('');
            }
        } catch (err) {
            feed.innerHTML = `<div class="p-4 text-center text-rose-400">Failed loading experiences: ${err.message}</div>`;
        }
    }

    static async handleExperienceSubmit() {
        const alias = document.getElementById('exp-alias').value;
        const title = document.getElementById('exp-threat-title').value;
        const text = document.getElementById('exp-text').value;

        try {
            await TrinetraAPI.submitReview({
                threat_title: title,
                user_alias: alias,
                community: this.state.activeCommunity,
                experience_text: text,
                platform: 'WhatsApp',
                action_taken: 'Reported & Blocked'
            });
            document.getElementById('experience-modal')?.classList.add('hidden');
            document.getElementById('exp-form')?.reset();
            this.loadReviewsData();
            alert('Your experience has been posted to Firestore!');
        } catch (err) {
            alert('Error sharing experience: ' + err.message);
        }
    }

    // --- ALERTS ---
    static async refreshAlerts() {
        try {
            const data = await TrinetraAPI.getAlerts(this.state.activeCommunity);
            const badge = document.getElementById('alert-badge');
            if (badge) {
                if (data.total > 0) {
                    badge.textContent = data.total;
                    badge.classList.remove('hidden');
                } else {
                    badge.classList.add('hidden');
                }
            }
        } catch (e) {
            console.warn('Alert check error', e);
        }
    }

    // --- SOC HEALTH LOADER ---
    static async loadHealthData() {
        try {
            const data = await TrinetraAPI.getDatabaseHealth();
            const studentCount = document.getElementById('health-student-count');
            const studentStatus = document.getElementById('health-student-status');
            if (studentCount) studentCount.textContent = data.student_threats;
            if (studentStatus) studentStatus.textContent = `${data.student_threats} / 15 ${data.student_valid ? '✓' : '❌'}`;

            const seniorCount = document.getElementById('health-senior-count');
            const seniorStatus = document.getElementById('health-senior-status');
            if (seniorCount) seniorCount.textContent = data.senior_citizen_threats;
            if (seniorStatus) seniorStatus.textContent = `${data.senior_citizen_threats} / 15 ${data.senior_citizen_valid ? '✓' : '❌'}`;

            const busCount = document.getElementById('health-business-count');
            const busStatus = document.getElementById('health-business-status');
            if (busCount) busCount.textContent = data.small_business_threats;
            if (busStatus) busStatus.textContent = `${data.small_business_threats} / 15 ${data.small_business_valid ? '✓' : '❌'}`;

            const regCount = document.getElementById('health-regional-count');
            const regStatus = document.getElementById('health-regional-status');
            if (regCount) regCount.textContent = data.regional_community_threats;
            if (regStatus) regStatus.textContent = `${data.regional_community_threats} / 15 ${data.regional_community_valid ? '✓' : '❌'}`;

            const totalCount = document.getElementById('health-total-count');
            const totalStatus = document.getElementById('health-total-status');
            if (totalCount) totalCount.textContent = data.total_threats;
            if (totalStatus) totalStatus.textContent = data.is_60_threats_validated ? 'PASSED ✓' : 'FAILED ❌';

            if (data.firebase_status) {
                const fbInit = document.getElementById('health-fb-init');
                const fsMode = document.getElementById('health-fs-mode');
                if (fbInit) fbInit.textContent = data.firebase_status.firebase;
                if (fsMode) fsMode.textContent = data.firebase_status.mode;
            }
        } catch (err) {
            console.error('Failed loading health data', err);
        }
    }
}
