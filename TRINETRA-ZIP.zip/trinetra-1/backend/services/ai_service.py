import os
import json
import logging
import re
from typing import Dict, Any, List, Optional
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger("trinetra.ai_service")

class AIService:
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY")
        self.model = None
        if self.api_key:
            try:
                import google.generativeai as genai
                genai.configure(api_key=self.api_key)
                self.model = genai.GenerativeModel("gemini-1.5-flash")
                logger.info("Gemini AI client configured successfully.")
            except Exception as e:
                logger.warning(f"Could not initialize Gemini AI client: {e}")

    def clean_json_response(self, text: str) -> str:
        # Strip markdown codeblocks ```json ... ```
        text = text.strip()
        text = re.sub(r"^```json\s*", "", text, flags=re.IGNORECASE)
        text = re.sub(r"^```\s*", "", text)
        text = re.sub(r"\s*```$", "", text)
        return text.strip()

    def validate_threat_json(self, data: Dict[str, Any]) -> bool:
        required = ["title", "threat_type", "severity", "community", "description"]
        for field in required:
            if not data.get(field):
                return False
        if data.get("severity") not in ["LOW", "MEDIUM", "HIGH", "CRITICAL"]:
            return False
        return True

    def simplify_threat_for_community(self, threat: Dict[str, Any], target_community: str) -> str:
        title = threat.get("title", "")
        desc = threat.get("description", "")
        method = threat.get("attack_method", "")
        comm = target_community.upper()

        if comm == "STUDENT":
            return f"Caution regarding '{title}': Scammers may send deceptive links or offers on messaging platforms targeting your college credentials, internships, or exam fees. {desc}"
        elif comm == "SENIOR_CITIZEN":
            return f"Important warning about '{title}': Fraudsters might call or message claiming to be bank or government officials asking for your OTP or PIN. Please do not share any codes or install remote applications. {desc}"
        elif comm == "SMALL_BUSINESS":
            return f"Cyber security alert for '{title}': Attackers are targeting company accounts and payment channels via fake invoices, executive impersonation, or malicious file attachments. {desc}"
        elif comm == "REGIONAL_COMMUNITY":
            return f"Regional warning about '{title}': Deceptive messages in local languages are offering fake government subsidies or electricity bill payments. {desc}"
        else:
            return desc

    def generate_chat_response(self, message: str, community: str = "STUDENT", history: List[Dict[str, str]] = None) -> str:
        comm_upper = (community or "STUDENT").upper()
        
        system_prompts = {
            "STUDENT": "You are TRINETRA AI Assistant, a friendly and expert cybersecurity guide for students. Explain technical threats clearly without jargon. Focus on internship scams, exam scams, social media hacking, online courses, loan apps, and campus safety.",
            "SENIOR_CITIZEN": "You are TRINETRA AI Assistant, a patient, polite, and reassuring cybersecurity companion for senior citizens. Use simple, non-technical language. Remind them never to share OTPs, PINs, or install remote access apps.",
            "SMALL_BUSINESS": "You are TRINETRA AI Assistant, an enterprise cybersecurity advisor for small and medium businesses. Provide practical, actionable guidance on invoice fraud, BEC, ransomware, vendor spoofing, and employee awareness.",
            "REGIONAL_COMMUNITY": "You are TRINETRA AI Assistant, a community-focused cyber safety guide for regional citizens. Explain scams involving local government schemes, regional festival offers, utility bills, and regional language phishing."
        }

        sys_context = system_prompts.get(comm_upper, system_prompts["STUDENT"])

        if self.model:
            try:
                full_prompt = f"{sys_context}\n\nUser Question ({comm_upper}): {message}\nProvide a clear, reassuring, and step-by-step safety response:"
                response = self.model.generate_content(full_prompt)
                if response and response.text:
                    return response.text.strip()
            except Exception as e:
                logger.error(f"Gemini API chat call failed: {e}")

        # Fallback intelligent rule-based cybersecurity response engine
        msg_lower = message.lower()

        if any(k in msg_lower for k in ["internship", "job", "part-time", "registration fee", "stipend"]):
            if comm_upper == "STUDENT":
                return ("⚠️ **Potential Internship / Job Scam Alert**\n\n"
                        "1. **Never pay upfront fees:** Legitimate companies never charge registration fees or laptop deposits for internships.\n"
                        "2. **Verify official website:** Check the company's official career page or LinkedIn instead of trusting WhatsApp/Telegram messages.\n"
                        "3. **Check email domain:** Genuine recruiters use company domains (e.g. `@company.com`), not free `@gmail.com` or `@outlook.com` addresses.\n"
                        "4. **Action:** Do not transfer money. Block the contact and report to your college placement cell.")
            else:
                return ("⚠️ **Employment & Freelancing Fraud Alert**\n\n"
                        "Be cautious of unsolicited job offers asking for advance fees or training charges. Always verify company registration before sharing documents.")

        elif any(k in msg_lower for k in ["otp", "bank", "kyc", "account block", "pension", "sim"]):
            return ("🚨 **HIGH RISK: Bank / KYC / OTP Fraud Alert**\n\n"
                    "1. **DO NOT SHARE YOUR OTP OR PIN:** No bank, government official, or pension authority will EVER ask for your OTP over phone or SMS.\n"
                    "2. **Do not install remote apps:** Never download apps like AnyDesk, TeamViewer, or QuickSupport if asked by a caller.\n"
                    "3. **Verify directly:** Hang up and call your bank's official number printed on your debit card or passbook.\n"
                    "4. **Helpline:** If money was fraudulently debited, immediately call the National Cyber Crime Helpline at **1930**.")

        elif any(k in msg_lower for k in ["invoice", "vendor", "ceo", "tax", "gst", "wire", "payment"]):
            return ("💼 **Small Business Threat Alert**\n\n"
                    "1. **Out-of-band verification:** Before changing vendor bank account details, call the vendor using a known offline phone number.\n"
                    "2. **Inspect domain names:** Look closely for subtle typosquatting in email domains (e.g., `suppl1er.com` vs `supplier.com`).\n"
                    "3. **Two-Factor Authentication:** Ensure 2FA is strictly enforced across all business email and cloud accounting portals.")

        elif any(k in msg_lower for k in ["electricity", "bill", "festival", "lottery", "scheme", "regional"]):
            return ("📢 **Regional Utility & Scheme Scam Warning**\n\n"
                    "1. **Ignore disconnection threats:** Electricity boards never send SMS threatening immediate power cut at night with a personal cell phone number.\n"
                    "2. **Do not click suspicious links:** Avoid clicking short links (`bit.ly`, `tinyurl`) claiming festival rewards or government subsidies.\n"
                    "3. **Official portal:** Pay utility bills only via official government apps or physical electricity board counters.")

        return (f"🛡️ **TRINETRA Safety Guidance ({comm_upper})**\n\n"
                f"Thank you for reaching out. Based on your query regarding '{message}':\n"
                "• **Verify Source:** Always double-check sender URLs, email addresses, and phone numbers.\n"
                "• **Never Share Credentials:** Keep passwords, OTPs, and personal identity documents secure.\n"
                "• **Report Incidents:** You can log a report directly on TRINETRA or call National Cybercrime Helpline 1930.")
